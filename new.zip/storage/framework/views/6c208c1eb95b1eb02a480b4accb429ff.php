

<?php $__env->startSection('title', 'Admin | All Users Trips'); ?>

<?php $__env->startSection('content'); ?>
<div class="db-info-wrap">
    <div class="row">
        <div class="col-lg-12">
            <div class="dashboard-box table-opp-color-box">
                <h4>Complain by user for driver</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>User Name</th>
                                <th>Driver</th>
                                <th>Messaage</th>
                                <th>Action</th>
                              
                          
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $complain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(\App\Models\User::where(['id' => $trip->user_id])->value('name')); ?></td>

                                <td><?php echo e(\App\Models\User::where(['id' => $trip->driver_id])->value('name')); ?></td>
                                <td><?php echo e($trip->message); ?></td>
                                <td>
                                      <a data-toggle="tooltip" data-placement="top" <?php if(\App\Models\User::where(['id' => $trip->driver_id])->value('status')==0): ?> title="Disable Driver"  <?php else: ?> title="Enable Driver" <?php endif; ?>  href="<?php echo e(route('admin.status', $trip->driver_id)); ?>" class="btn btn-danger"><?php if(\App\Models\User::where(['id' => $trip->driver_id])->value('status')==0): ?> <i class="fas fa-ban text-white"></i>  <?php else: ?> <i class="fas fa-check text-white"></i>  <?php endif; ?> </a></td>
                            
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    <?php if(session('error')): ?>
        swal({
            title: "Error",
            text: "<?php echo e(session('error')); ?>",
            icon: "error",
            button: "OK",
        });
    <?php endif; ?>
    <?php if(session('success')): ?>
        swal({
            title: "Success",
            text: "<?php echo e(session('success')); ?>",
            icon: "success",
            button: "OK",
        });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.tourist_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/admin/complain.blade.php ENDPATH**/ ?>