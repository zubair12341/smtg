<header id="masthead" class="site-header header-primary">
    <!-- header html start -->
    <div class="top-header">
       <div class="container">
          <div class="row">
             <div class="col-lg-8 d-none d-lg-block">
                <div class="header-contact-info">
                   <ul>
                      <li>
                         <a href="#"><i class="fas fa-phone-alt"></i> +92 (111) 1111 11</a>
                      </li>
                      <li>
                         <a href="mailto:info@Travel.com"><i class="fas fa-envelope"></i> iqra@iqra.edu.pk</a>
                      </li>
                      <li>
                         <i class="fas fa-map-marker-alt"></i> Iqra University North Campus
                      </li>
                   </ul>
                </div>
             </div>
             <div class="col-lg-4 d-flex justify-content-lg-end justify-content-between">
                <div class="header-social social-links">
                   <ul>
                      <li><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                      <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                      <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                      <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                   </ul>
                </div>
                <div class="header-search-icon">
                   <button class="search-icon">
                      <i class="fas fa-search"></i>
                   </button>
                </div>
             </div>
          </div>
       </div>
    </div>
    <div class="bottom-header">
       <div class="container d-flex justify-content-between align-items-center">
          <div class="site-identity">
             <h1 class="site-title">
                <a href="<?php echo e(url('/')); ?>">
                   <img class="white-logo" src="<?php echo e(asset('assets/images/travele-logo.png')); ?>" alt="logo">
                   <img class="black-logo" src="<?php echo e(asset('assets/images/travele-logo1.png')); ?>" alt="logo">
                </a>
             </h1>
          </div>
          <div class="main-navigation d-none d-lg-block">
             <nav id="navigation" class="navigation">
                <ul>
                   <li class="menu-item">
                      <a href="<?php echo e(url('/')); ?>">Home</a>
                   </li>
                   <li class="menu-item">
                     <a href="<?php echo e(url('/about')); ?>">About</a>
                   </li>
                   <li class="menu-item">
                      <a href="<?php echo e(url('/destination')); ?>">Destinations</a>
                   </li>
                   
                   <li class="menu-item">
                    <a href="<?php echo e(url('/contact')); ?>">Contact</a>
                  </li>
                  <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                    <li class="menu-item">
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                      </li>
                    <?php endif; ?>
                <?php else: ?>
                <?php endif; ?>

                <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                <li class="menu-item-has-children">
                    <?php
                $userType = Auth::user()->user_type;
            ?>
                    <a href="#Dashboard">Dashboard</a>
                    <ul>
                       <li>
                        <?php if($userType === 'Admin'): ?>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                        <?php elseif($userType === 'Hotel'): ?>
                            <a href="<?php echo e(route('vendor.dashboard')); ?>">Dashboard</a>
                        <?php elseif($userType === 'Tourist'): ?>
                            <a href="<?php echo e(route('tourist.dashboard')); ?>">Dashboard</a>
                        <?php elseif($userType === 'Driver'): ?>
                            <a href="<?php echo e(route('driver.dashboard')); ?>">Dashboard</a>
                        <?php else: ?>
                        <?php endif; ?>
                       </li>
                       <li>
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Logout
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                        </li>
                    </ul>
                 </li>
                <?php endif; ?>
                <?php endif; ?>

                </ul>
             </nav>
          </div>
          <div class="header-btn">
            <?php if(Auth::check()): ?>
            <?php
                $userType = Auth::user()->user_type;
            ?>
            <?php if($userType === 'Tourist'): ?>
            <a class="button-primary" href="<?php echo e(route('create_trip')); ?>">Create Trip</a>
            <?php endif; ?>
            &nbsp;
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('register')): ?>
                     <a class="button-primary" href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                <?php else: ?>
                <?php endif; ?>
          </div>
       </div>
    </div>
    <div class="mobile-menu-container"></div>
 </header>
<?php /**PATH D:\umer\new\resources\views/include/header.blade.php ENDPATH**/ ?>