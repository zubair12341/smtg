<?php $__env->startSection('title', 'Admin Edit User'); ?>
<?php $__env->startSection('content'); ?>

<div class="db-info-wrap">
    <div class="row">


        <div class="col">
            <div class="dashboard-box table-opp-color-box" style="height: 500px">
            <h2>Edit User</h2>

    <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row mt-3">
          <div class="col">
            <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e($user->name); ?>" required>
          </div>
          <div class="col">
            <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e($user->email); ?>" requireds>
          </div>
        </div>
        <div class="row mt-3">
            <div class="col">
              <input type="text" class="form-control" name="country" placeholder="Name" value="<?php echo e($user->country); ?>" placeholder="Country Name" required>
            </div>
            <div class="col">
              <input type="text" class="form-control" name="state" placeholder="Email" value="<?php echo e($user->state); ?>" placeholder="State Name" requireds>
            </div>
          </div>
          <div class="row mt-3">
            <div class="col">
              <input type="text" class="form-control" name="city" placeholder="Name" value="<?php echo e($user->city); ?>" placeholder="City Name" required>
            </div>
            <div class="col">
              <input type="number" class="form-control" name="phone" placeholder="Email" value="<?php echo e($user->phone); ?>" placeholder="Phone Name" requireds>
            </div>
          </div>
        <div class="row mt-3">
            <div class="col">
                <input type="password" class="form-control" name="password" placeholder="Enter password if you want to update, Otherwise leave it null">
            </div>
        </div>
        <div class="row mt-3">
            <div class="col">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
      </form>

    </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/users/edit.blade.php ENDPATH**/ ?>