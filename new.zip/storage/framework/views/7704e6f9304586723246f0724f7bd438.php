
<?php $__env->startSection('title', 'My Trips'); ?>
<?php $__env->startSection('content'); ?>
    <div class="db-info-wrap">
        <div class="row">
            <div class="col-lg-12">
                <div class="dashboard-box table-opp-color-box">
                    <h4>My Trips</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Destination</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Status By Driver</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($trip->destination); ?></td>
                                        <td><?php echo e($trip->start_date); ?></td>
                                        <td><?php echo e($trip->end_date); ?></td>
                                        <td><?php echo e($trip->status_by_driver); ?>

                                            <?php if($trip->status_by_driver == 'rejected'): ?>
                                                <p style="color: red;font-size:12px" class="text_danger">Your driver has
                                                    reject the offer. <br> kindly go to edit and choose another driver</p>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a data-toggle="tooltip" data-placement="top" title="View" href="<?php echo e(route('view_trip', ['id' => $trip->id])); ?>"
                                                class="btn btn-secondary btn-sm text-white"><i class="fas fa-eye"></i></a>
                                            <?php if($trip->status_by_driver != 'complete'): ?>
                                                <a data-toggle="tooltip" data-placement="top" title="Edit" href="<?php echo e(route('edit_trip', ['id' => $trip->id])); ?>"
                                                    class="btn btn-primary btn-sm text-white"><i
                                                        class="fas fa-edit"></i></a>
                                            <?php endif; ?>
                                            <a data-toggle="tooltip" data-placement="top" title="Delete" href="#0" class="btn btn-danger btn-sm text-white delete_trip1"
                                                data-id="<?php echo e($trip->id); ?>"
                                                data-url="<?php echo e(route('delete_trip', ['id' => $trip->id])); ?>"><i
                                                    class="fas fa-trash"></i></a>

                                            <a data-toggle="tooltip" data-placement="top" title="Complain against driver" href="<?php echo e(route('complain.page', $trip->id)); ?>"
                                                class="btn btn-warning btn-sm text-white"><i
                                                    class="fas fa-comments"></i></a>
                                            <?php

                                                $end_date = Carbon\Carbon::parse($trip->end_date);
                                                $current_date = Carbon\Carbon::now();

                                            ?>
                                            <?php if($trip->status_by_driver != 'complete'): ?>
                                                <?php if($end_date->lessThan($current_date)): ?>
                                                    <a data-toggle="tooltip" data-placement="top" title="Trip Complete" href="<?php echo e(route('trip.completed', $trip->id)); ?>"
                                                        class="btn btn-dark btn-sm text-white"><i
                                                            class="fas fa-check"></i></a>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if($trip->status_by_driver == 'complete'): ?>
                                            <a data-toggle="tooltip" data-placement="top" title="Review about trip" href="<?php echo e(route('trip.rating', $trip->id)); ?>"
                                                class="btn btn-success btn-sm text-white"><i
                                                    class="fas fa-star"></i></a>
                                            <?php endif; ?>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        <?php if(session('error')): ?>
            swal({
                title: "Error",
                text: "<?php echo e(session('error')); ?>",
                icon: "error",
                button: "OK",
            });
        <?php endif; ?>
        <?php if(session('success')): ?>
            swal({
                title: "Success",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        <?php endif; ?>
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        let trip_id = null
        $(document).on('click', '.delete_trip1', function() {
            trip_id = $(this).data('id');
            let text = "Do you really want to delete this trip";
            if (confirm(text) == true) {
                console.log($(this).data('url'));
                window.location = $(this).data('url')
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.tourist_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/tourist/trips.blade.php ENDPATH**/ ?>