<?php $__env->startSection('title', 'Change Password'); ?>
<?php $__env->startSection('content'); ?>
    

<style>
    .my_img{
        height: 70px;
    border-radius: 50%;
    margin-top: -19px;
    margin-left: 20px;
    }
</style>

    <div class="db-info-wrap">
        <div class="row mt-3">
            <div class="col-lg-12 mt-5">
                <div class="dashboard-box table-opp-color-box">
                    <div class="d-flex">
                        <h4>Update Profile</h4>
                        <?php if(auth()->user()->image!=null): ?>
                        <img src="<?php echo e(auth()->user()->image); ?>" class="my_img" alt="">
                        <?php else: ?>
                        <img src="https://static.vecteezy.com/system/resources/previews/008/442/086/non_2x/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg" class="my_img" alt="">
                        <?php endif; ?>
                    </div>
                   


                    <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-6">


                                <div class="form-group">
                                    <label for="current_password">Name</label>
                                    <input type="text" name="name" value="<?php echo e(auth()->user()->name); ?>"
                                        class="form-control" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="current_password">Email</label>
                                    <input type="text" name="email" value="<?php echo e(auth()->user()->email); ?>"
                                        class="form-control" required>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="current_password">Country</label>
                                    <input type="text" name="country" value="<?php echo e(auth()->user()->country); ?>"
                                        class="form-control" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="current_password">City</label>
                                    <input type="text" name="city" value="<?php echo e(auth()->user()->city); ?>"
                                        class="form-control" required>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="current_password">State</label>
                                    <input type="text" name="state" value="<?php echo e(auth()->user()->state); ?>"
                                        class="form-control" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="current_password">Phone Number</label>
                                    <input type="text" name="phone" value="<?php echo e(auth()->user()->phone); ?>"
                                        class="form-control" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="current_password">Profile Image</label>
                                    <input type="file" name="image" class="form-control" >
                                </div>
                            </div>
                            <div class="col-6">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <button style="margin-top: 35px" type="submit" class="btn btn-primary">Update Profile</button>
                            </div>
                        </div>
                    </form>
                    <br>
                    <hr>
                    <h4>Change Password</h4>
                    <br>
                    <form method="POST" action="<?php echo e(route('password.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="current_password">Current Password</label>
                                    <input type="password" name="current_password" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="new_password">New Password</label>
                                    <input type="password" name="new_password" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="new_password_confirmation">Confirm New Password</label>
                                    <input type="password" name="new_password_confirmation" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <button style="margin-top: 35px" type="submit" class="btn btn-primary">Change
                                    Password</button>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>


    <script>
        <?php if(session('error')): ?>
            swal({
                title: "Error",
                text: "<?php echo e(session('error')); ?>",
                icon: "error",
                button: "OK",
            });
        <?php endif; ?>
        <?php if(session('success')): ?>
            swal({
                title: "Success",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/admin/changepass.blade.php ENDPATH**/ ?>