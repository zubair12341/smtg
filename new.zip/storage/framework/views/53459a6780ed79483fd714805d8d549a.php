<?php $__env->startSection('title', 'Admin | All Users Trips'); ?>

<?php $__env->startSection('content'); ?>
<div class="db-info-wrap">
    <div class="row">
        <div class="col-lg-12">
            <div class="dashboard-box table-opp-color-box">
                <h4>Users Trips</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Destination</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(\App\Models\User::where(['id' => $trip->user_id])->value('name')); ?></td>

                                <td><?php echo e($trip->destination); ?></td>
                                <td><?php echo e($trip->start_date); ?></td>
                                <td><?php echo e($trip->end_date); ?></td>
                                <td>
                                    <a data-toggle="tooltip" data-placement="top" title="View Trip" href="<?php echo e(route('admin.view_trip', ['id'=>$trip->id])); ?>" class="btn btn-primary btn-sm text-white"><i class="fas fa-eye"></i></a>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    let trip_id = null
    $(document).on('click','.delete_trip1',function(){
        trip_id = $(this).data('id');
        let text = "Do you really want to delete this trip";
        if (confirm(text) == true) {
            console.log($(this).data('url'));
            window.location=$(this).data('url')
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.tourist_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/admin/trips.blade.php ENDPATH**/ ?>