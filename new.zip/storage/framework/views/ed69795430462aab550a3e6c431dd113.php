<?php $__env->startSection('title', 'Admin Users'); ?>
<?php $__env->startSection('content'); ?>

<div class="db-info-wrap">
    <div class="row">
        <!-- Item -->
        <!-- Item -->
        <div class="col-xl-3 col-sm-6">
            <div class="db-info-list">
                <div class="dashboard-stat-icon bg-green">
                    <i class="fas fa-users"></i>
                </div>
                <div class="dashboard-stat-content">
                    <h4>Total Users</h4>
                    <h5><?php echo e($total_users); ?></h5>
                </div>
            </div>
        </div>
        <!-- Item -->
        <div class="col-xl-3 col-sm-6">
            <div class="db-info-list">
                <div class="dashboard-stat-icon bg-purple">
                    <i class="fas fa-users"></i>
                </div>
                <div class="dashboard-stat-content">
                    <h4>Tourists</h4>
                    <h5><?php echo e($tourists); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6">
            <div class="db-info-list">
                <div class="dashboard-stat-icon bg-red">
                    <i class="fas fa-users"></i>
                </div>
                <div class="dashboard-stat-content">
                    <h4>Drivers</h4>
                    <h5><?php echo e($drivers); ?></h5>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-lg-12 mt-5">
            <div class="dashboard-box table-opp-color-box">
                <h4>All Users</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>User Type</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i=1;
                            ?>
                            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><a href="#"><span class="list-name"><?php echo e($all->name); ?></span><span class="list-enq-city">Pakistan</span></a>
                                </td>
                                <td><?php echo e($all->email); ?></td>
                                <td>
                                    <span class="badge <?php if($all->user_type=='Driver'): ?> badge-dark <?php else: ?> badge-primary <?php endif; ?>"><?php echo e($all->user_type); ?></span>
                                </td>
                                <td>
                                    <a data-toggle="tooltip" data-placement="top" title="Edit"   href="<?php echo e(route('users.edit', $all->id)); ?>" class="btn btn-warning"> <i class="fas fa-edit text-white"></i></a>
                                    <form action="<?php echo e(route('users.destroy', $all->id)); ?>" method="POST" style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button data-toggle="tooltip" data-placement="top" title="Delete" type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?')"> <i class="fas fa-trash text-white"></i></button>
                                    </form>

                                    <a data-toggle="tooltip" data-placement="top" <?php if($all->status==0): ?> title="Disable User"  <?php else: ?> title="Enable User" <?php endif; ?> href="<?php echo e(route('admin.status', $all->id)); ?>" class="btn btn-dark"><?php if($all->status==0): ?> <i class="fas fa-ban text-white"></i> <?php else: ?>  <i class="fas fa-check text-white"></i> <?php endif; ?> </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>


    <script>
        <?php if(session('error')): ?>
            swal({
                title: "Error",
                text: "<?php echo e(session('error')); ?>",
                icon: "error",
                button: "OK",
            });
        <?php endif; ?>
        <?php if(session('success')): ?>
            swal({
                title: "Success",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        <?php endif; ?>
    </script>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/admin/users.blade.php ENDPATH**/ ?>