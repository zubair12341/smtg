<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets2/css/bootstrap.min.css')); ?>" media="all">
    <!-- Fonts Awesome CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets2/css/all.min.css')); ?>">
    <!-- google fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,400&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&display=swap"
        rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets2/css/style.css')); ?>">
    <title>Smart Tour Guide | Register </title>
</head>

<body>
    <div class="login-page" style="background-image: url(<?php echo e(asset('assets2/images/bg.jpg')); ?>); height: 100%;">
        <div class="login-from-wrap" style="">

            <form method="POST" action="<?php echo e(route('register')); ?>" class="login-from" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h1 class="site-title">
                    <a href="#">
                        <img src="<?php echo e(asset('assets2/images/logo.png')); ?>" alt="">
                    </a>
                </h1>
                <div class="row">
                    <?php
                        $userData = session()->get('userData');
                        // dump($userData);
                    ?>
                    <?php if(isset($userData)): ?>
                    <input type="hidden" name="my_image" value="<?php echo e($userData['image']); ?>">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="first_name1">Name <b style="color: red">*</b></label>
                                <input type="text" name="name"
                                    class="validate <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($userData['name']); ?>"
                                    readonly required autocomplete="name" autofocus>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="first_name1">Email <b style="color: red">*</b></label>
                                <input type="text" name="email"
                                    class="validate <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e($userData['email']); ?>" readonly required autocomplete="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="last_name">User Type <b style="color: red">*</b></label>
                                <select name="user_type" id="user_type" class="form-controll" required
                                    onchange="showFields()">
                                    <option value="" disabled selected>Choose User Type</option>
                                    <option value="Tourist">Tourist</option>
                                    <option value="Driver">Driver</option>
                                </select>
                                <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="first_name1">Name <b style="color: red">*</b></label>
                                <input type="text" name="name"
                                    class="validate <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>"
                                    required autocomplete="name" autofocus>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="first_name1">Email <b style="color: red">*</b></label>
                                <input type="text" name="email"
                                    class="validate <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>"
                                    required autocomplete="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row">
                                <div class="form-group col">
                                    <label for="last_name">Password <b style="color: red">*</b></label>
                                    <input id="last_name" name="password" type="password"
                                        class="validate <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                        autocomplete="current-password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col">
                                    <label for="last_name">Confirm Password <b style="color: red">*</b></label>
                                    <input id="last_name" name="password_confirmation" type="password"
                                        class="validate <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                        autocomplete="new-password">
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="last_name">User Type <b style="color: red">*</b></label>
                                <select name="user_type" id="user_type" class="form-controll" required
                                    onchange="showFields()">
                                    <option value="" disabled selected>Choose User Type</option>
                                    <option value="Tourist">Tourist</option>
                                    <option value="Driver">Driver</option>
                                </select>
                                <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="last_name">Upload Profile</label>
                                <input type="file" name="image" class="form-control">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="col-6">

                        <div class="row">
                            <div class="col form-group">
                                <label for="">Country <b style="color: red">*</b></label>
                                <input type="text" name="country" class="fomr-controll"
                                    placeholder="enter you country name">
                            </div>
                            <div class="col form-group">
                                <label for="">State <b style="color: red">*</b></label>
                                <input type="text" name="state" placeholder="enter your state name"
                                    class="fomr-controll">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col form-group">
                                <label for="">City <b style="color: red">*</b></label>

                                <select name="city">
                                    <option value="" disabled selected>Select The City</option>
                                    <option value="Islamabad">Islamabad</option>
                                    <option value="" disabled>Punjab Cities</option>
                                    
                                    <option value="Bahawalpur">Bahawalpur</option>
                                    
                                    <option value="Gujranwala">Gujranwala</option>
                                    
                                    <option value="Lahore">Lahore</option>
                                    
                                    <option value="Mianwali">Mianwali</option>
                                    <option value="Multan">Multan</option>
                                    <option value="Murree">Murree</option>
                                    
                                    <option value="Sargodha">Sargodha</option>
                                    
                                    <option value="Sialkot">Sialkot</option>
                                    
                                    <option value="Wazirabad">Wazirabad</option>
                                    <option value="" disabled>Sindh Cities</option>
                                    
                                    <option value="Hyderabad">Hyderabad</option>
                                    
                                    <option value="Karachi">Karachi</option>
                                    
                                    <option value="Mirpur Khas">Mirpur Khas</option>
                                    
                                    <option value="Nawabshah">Nawabshah</option>
                                    
                                    <option value="Rohri">Rohri</option>
                                    
                                    <option value="Sukkur">Sukkur</option>
                                    
                                    <option value="" disabled>Khyber Cities</option>
                                    <option value="Abbottabad">Abbottabad</option>
                                    
                                    <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                                    <option value="Mansehra">Mansehra</option>
                                    <option value="Peshawar">Peshawar</option>
                                    
                                    <option value="" disabled>Balochistan Cities</option>
                                    
                                    <option value="Gwadar">Gwadar</option>
                                    
                                    <option value="Quetta">Quetta</option>
                                    
                                    <option value="Ziarat">Ziarat</option>
                                </select>
                            </div>
                            <div class="col form-group">
                                <label for="">phone <b style="color: red">*</b></label>
                                <input type="number" name="phone" placeholder="enter your phone no"
                                    class="fomr-controll">
                            </div>
                        </div>

                        <hr style="padding-bottom: 5px; padding-top:5px;">

                        
                        <div id="touristFields" style="display: none;">
                            <!-- Tourist Fields -->

                            <div class="form-group">
                                <label for="last_name">Place Type</label>
                                <select name="place_type" id="place_type" class="form-controll" required
                                    onchange="showFields()">
                                    <option value="Nature">Nature</option>
                                    <option value="Religious">Religious</option>
                                    <option value="Architect">Architect</option>
                                </select>
                                <?php $__errorArgs = ['place_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="last_name">Food Type <b style="color: red">*</b></label>
                                <select name="food_type" id="food_type" class="form-controll" required
                                    onchange="showFields()">
                                    <option value="Desi Food">Desi Food</option>
                                    <option value="Chinees">Chinees</option>
                                    <option value="Italian">Italian</option>
                                </select>
                                <?php $__errorArgs = ['food_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="last_name">Accomodation Type <b style="color: red">*</b></label>
                                <select name="accomodation_type" id="accomodation_type" class="form-controll"
                                    required onchange="showFields()">
                                    <option value="High Rated">High Rated</option>
                                    <option value="Average Rated">Average Rated</option>
                                    <option value="Cheap Rated">Cheap Rated</option>
                                </select>
                                <?php $__errorArgs = ['accomodation_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div id="driverFields"
                            style="display: none; overflow-y: scroll;overflow-x: hidden; height: 600px; padding 15px">
                            <!-- Driver Fields -->
                            <div class="row">
                                <div class="form-group col">
                                    <label for="">Age <b style="color: red">*</b></label>
                                    <input type="number" name="age" placeholder="enter your age"
                                        class="fomr-controll">
                                </div>
                                <div class="form-group col">
                                    <label for="">CNIC (without brackets) <b style="color: red">*</b></label>
                                    <input type="number" name="cnic" placeholder="enter your cnic"
                                        class="fomr-controll">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="">Address <b style="color: red">*</b></label>
                                <input type="text" name="address" placeholder="enter your complete address"
                                    class="fomr-controll">
                            </div>
                            <div class="form-group">
                                <label for="">Location <b style="color: red">*</b></label>
                                <input type="text" name="location" placeholder="enter your complete address"
                                    class="fomr-controll">
                            </div>
                            <div class="form-group">
                                <textarea name="driver_personal_info" id="" cols="3" rows="2" placeholder="Personal Info"></textarea>
                            </div>
                            <div class="row">
                                <div class="form-group col">
                                    <label for="">Price per day <b style="color: red">*</b></label>
                                    <input type="number" name="price_per_day" placeholder="enter price per day"
                                        class="fomr-controll">
                                </div>
                                <div class="form-group col">
                                    <label for="last_name">Vehicle Type <b style="color: red">*</b></label>
                                    <select name="vehicle_type" id="vehicle_type" class="form-controll">
                                        <option value="Sedan">Sedan</option>
                                        <option value="SUV">SUV</option>
                                        <option value="Hatchback">Hatchback</option>
                                        <option value="Minivan">Minivan</option>
                                    </select>
                                    <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col">
                                    <label for="">Model <b style="color: red">*</b></label>
                                    <input type="text" name="model" placeholder="enter car model"
                                        class="fomr-controll">
                                </div>
                                <div class="form-group col">
                                    <label for="">Manufacturer <b style="color: red">*</b></label>
                                    <input type="text" name="manufacturer" placeholder="enter car manufacturer"
                                        class="fomr-controll">
                                </div>
                            </div>
                        </div>

                        
                    </div>

                    <div class="form-group">
                        <button class="btn button-primary" type="submit">Register</button>
                        <a href="<?php echo e(route('forgot.page')); ?>" class="for-pass">Forgot Password?</a>
                    </div>
            </form>
        </div>
    </div>
    </div>

    <!-- *Scripts* -->
    <script src="<?php echo e(asset('assets2/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('assets2/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets2/js/canvasjs.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets2/js/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets2/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets2/js/dashboard-custom.js')); ?>"></script>
</body>

</html>

<script>
    function showFields() {
        var userType = document.getElementById('user_type').value;
        var touristFields = document.getElementById('touristFields');
        var driverFields = document.getElementById('driverFields');

        if (userType === 'Tourist') {
            touristFields.style.display = 'block';
            driverFields.style.display = 'none';
        } else if (userType === 'Driver') {
            touristFields.style.display = 'none';
            driverFields.style.display = 'block';
        } else {
            touristFields.style.display = 'none';
            driverFields.style.display = 'none';
        }
    }
</script>
<?php /**PATH D:\umer\new\resources\views/auth/register.blade.php ENDPATH**/ ?>