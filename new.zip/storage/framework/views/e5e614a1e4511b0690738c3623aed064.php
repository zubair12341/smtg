<?php $__env->startSection('title', 'Tourist Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="db-info-wrap">
    <div class="row">
        <!-- Item -->
        <div class="col-xl-3 col-sm-6">
            <div class="db-info-list">
                <div class="dashboard-stat-icon bg-blue">
                    <i class="far fa-chart-bar"></i>
                </div>
                <div class="dashboard-stat-content">
                    <h4>Total Plans</h4>
                    <h5><?php echo e($mytrip_count); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="dashboard-box chart-box">
            <h4>My Trips month wise</h4>
            <div id="barchart" style="height: 250px; width: 100%;"></div>
            </div>
        </div>
</div>
    <div class="row">
        <div class="col-lg-12">
            <div class="dashboard-box">
                <h4>My Tour Plans</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Destination</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Status By Driver</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($trip->destination); ?></td>
                                <td><?php echo e($trip->start_date); ?></td>
                                <td><?php echo e($trip->end_date); ?></td>
                                <td><?php echo e($trip->status_by_driver); ?>

                                    <?php if($trip->status_by_driver=='rejected'): ?>
                                        <p style="color: red;font-size:12px" class="text_danger">Your driver has reject the offer. <br> kindly go to edit and choose another driver</p>
                                    <?php endif; ?>
                                    </td>
                                    <td>
                                        <a data-toggle="tooltip" data-placement="top" title="View" href="<?php echo e(route('view_trip', ['id' => $trip->id])); ?>"
                                            class="btn btn-primary btn-sm text-white"><i class="fas fa-eye"></i></a>
                                        <?php if($trip->status_by_driver != 'complete'): ?>
                                            <a data-toggle="tooltip" data-placement="top" title="Edit" href="<?php echo e(route('edit_trip', ['id' => $trip->id])); ?>"
                                                class="btn btn-primary btn-sm text-white"><i
                                                    class="fas fa-edit"></i></a>
                                        <?php endif; ?>
                                        <a data-toggle="tooltip" data-placement="top" title="Delete" href="#0" class="btn btn-danger btn-sm text-white delete_trip1"
                                            data-id="<?php echo e($trip->id); ?>"
                                            data-url="<?php echo e(route('delete_trip', ['id' => $trip->id])); ?>"><i
                                                class="fas fa-trash"></i></a>

                                        <a data-toggle="tooltip" data-placement="top" title="Complain against driver" href="<?php echo e(route('complain.page', $trip->id)); ?>"
                                            class="btn btn-warning btn-sm text-white"><i
                                                class="fas fa-comments"></i></a>
                                        <?php

                                            $end_date = Carbon\Carbon::parse($trip->end_date);
                                            $current_date = Carbon\Carbon::now();

                                        ?>
                                        <?php if($trip->status_by_driver != 'complete'): ?>
                                            <?php if($end_date->lessThan($current_date)): ?>
                                                <a data-toggle="tooltip" data-placement="top" title="Trip Complete" href="<?php echo e(route('trip.completed', $trip->id)); ?>"
                                                    class="btn btn-dark btn-sm text-white"><i
                                                        class="fas fa-check"></i></a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if($trip->status_by_driver == 'complete'): ?>
                                        <a data-toggle="tooltip" data-placement="top" title="Review about trip" href="<?php echo e(route('trip.rating', $trip->id)); ?>"
                                            class="btn btn-success btn-sm text-white"><i
                                                class="fas fa-star"></i></a>
                                        <?php endif; ?>
                                        
                                    </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

   
    <script>
        <?php if(session('error')): ?>
            swal({
                title: "Error",
                text: "<?php echo e(session('error')); ?>",
                icon: "error",
                button: "OK",
            });
        <?php endif; ?>
        <?php if(session('success')): ?>
            swal({
                title: "Success",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        <?php endif; ?>
    </script>
</div>
<style>
    .canvasjs-chart-credit{
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>

	//barchart

    $(document).ready(function(){

  
        <?php
$currentYear = \Carbon\Carbon::now()->year;

// Define trip counts for each month
$tripCounts = [
    $trip_jan->count(),
    $trip_feb->count(),
    $trip_mar->count(),
    $trip_apr->count(),
    $trip_may->count(),
    $trip_jun->count(),
    $trip_jul->count(),
    $trip_aug->count(),
    $trip_sep->count(),
    $trip_oct->count(),
    $trip_nov->count(),
    $trip_dec->count()
];

?>

var chart1 = new CanvasJS.Chart("barchart", {
    animationEnabled: true,
    theme: "light2",
    data: [{
        type: "column",
        showInLegend: true,
        legendMarkerColor: "grey",
        legendText: "Number of Trips according to month",
        dataPoints: [
            <?php $__currentLoopData = $tripCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                { y: <?php echo e($count); ?>, label: "<?php echo e(date('M', mktime(0, 0, 0, $key + 1, 1))); ?>" },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
    }]
});

chart1.render();


})
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.tourist_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/tourist/dashboard.blade.php ENDPATH**/ ?>