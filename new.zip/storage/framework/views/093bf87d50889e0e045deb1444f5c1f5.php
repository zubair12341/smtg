
<?php $__env->startSection('title', 'Driver Dashboard'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php $__env->startSection('content'); ?>

    <div class="db-info-wrap">


        <div class="row">
            <div class="col-lg-12">
                <div class="dashboard-box">
                    <h4>Trips Request</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tourist Name</th>
                                    <th>Destination</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($trips != null && count($trips) > 0): ?>
                                    <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(\App\Models\User::where(['id' => $singleTrip->user_id])->value('name')); ?>

                                            </td>
                                            <td><?php echo e($singleTrip->destination); ?></td>
                                            <td><?php echo e($singleTrip->start_date); ?></td>
                                            <td><?php echo e($singleTrip->end_date); ?></td>
                                            <td>
                                                <a data-toggle="tooltip" data-placement="top" title="View"
                                                    href="<?php echo e(route('view_trip', ['id' => $singleTrip->id])); ?>"
                                                    class="btn btn-primary btn-sm text-white"><i class="fas fa-eye"></i></a>
                                                <a data-toggle="tooltip" data-placement="top" title="Reject"
                                                    href="<?php echo e(route('reject.request', ['id' => $singleTrip->id])); ?>"
                                                    class="btn btn-danger btn-sm text-white"><i class="fas fa-ban"></i></a>
                                                <a data-toggle="tooltip" data-placement="top" title="Accept"
                                                    href="<?php echo e(route('except.request', ['id' => $singleTrip->id])); ?>"
                                                    class="btn btn-success btn-sm text-white"><i
                                                        class="fas fa-check"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td>
                                            <p>No Request avaiallable</p>
                                        </td>
                                    </tr>
                                    <!-- Handle case when $trips is empty or null -->
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>




        <div class="row">
            <div class="col-lg-12">
                <div class="dashboard-box">
                    <h4>Accepted Trip Request</h4>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tourist Name</th>
                                    <th>Destination</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($accepted_trips != null && count($accepted_trips) > 0): ?>
                                    <?php $__currentLoopData = $accepted_trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(\App\Models\User::where(['id' => $singleTrip->user_id])->value('name')); ?>

                                            </td>
                                            <td><?php echo e($singleTrip->destination); ?></td>
                                            <td><?php echo e($singleTrip->start_date); ?></td>
                                            <td><?php echo e($singleTrip->end_date); ?></td>
                                            <td>
                                                <a data-toggle="tooltip" data-placement="top" title="View"
                                                    href="<?php echo e(route('view_trip', ['id' => $singleTrip->id])); ?>"
                                                    class="btn btn-primary btn-sm text-white"><i class="fas fa-eye"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td>
                                            <p>No accepted Trips avaiallable</p>
                                        </td>
                                    </tr>
                                    <!-- Handle case when $trips is empty or null -->
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="dashboard-box">
                    <h4>Completed Trips</h4>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tourist Name</th>
                                    <th>Destination</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($comp_trips != null && count($comp_trips) > 0): ?>
                                    <?php $__currentLoopData = $comp_trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(\App\Models\User::where(['id' => $singleTrip->user_id])->value('name')); ?></td>
                                            <td><?php echo e($singleTrip->destination); ?></td>
                                            <td><?php echo e($singleTrip->start_date); ?></td>
                                            <td><?php echo e($singleTrip->end_date); ?></td>
                                            <td>
                                                <a data-toggle="tooltip" data-placement="top" title="View"
                                                    href="<?php echo e(route('view_trip', ['id' => $singleTrip->id])); ?>"
                                                    class="btn btn-primary btn-sm text-white">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td>
                                            <p>No completed Trips avaiallable</p>
                                        </td>
                                    </tr>
                                    <!-- Handle case when $trips is empty or null -->
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="dashboard-box">
                    <h4>Rejected Request</h4>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tourist Name</th>
                                    <th>Destination</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($rejected_trips != null && count($rejected_trips) > 0): ?>
                                    <?php $__currentLoopData = $rejected_trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(\App\Models\User::where(['id' => $singleTrip->user_id])->value('name')); ?>

                                            </td>
                                            <td><?php echo e($singleTrip->destination); ?></td>
                                            <td><?php echo e($singleTrip->start_date); ?></td>
                                            <td><?php echo e($singleTrip->end_date); ?></td>
                                            <td>
                                                <a data-toggle="tooltip" data-placement="top" title="View"
                                                    href="<?php echo e(route('view_trip', ['id' => $singleTrip->id])); ?>"
                                                    class="btn btn-primary btn-sm text-white"><i class="fas fa-eye"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td>
                                            <p>No accepted Trips avaiallable</p>
                                        </td>
                                    </tr>
                                    <!-- Handle case when $trips is empty or null -->
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <script>
            <?php if(session('error')): ?>
                swal({
                    title: "Error",
                    text: "<?php echo e(session('error')); ?>",
                    icon: "error",
                    button: "OK",
                });
            <?php endif; ?>
            <?php if(session('success')): ?>
                swal({
                    title: "Success",
                    text: "<?php echo e(session('success')); ?>",
                    icon: "success",
                    button: "OK",
                });
            <?php endif; ?>
        </script>





    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.tourist_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/driver/trip.blade.php ENDPATH**/ ?>