<?php $__env->startSection('title', 'Create Trip'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <style>
            .point_of_interest {
                max-height: 500px;
                overflow-y: auto;
            }

            .h-label {
                font-weight: 700;
                font-size: 28px;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <section class="inner-banner-wrap">
        <div class="inner-baner-container" style="background-image: url(<?php echo e(asset('assets/images/inner-banner.jpg')); ?>);">
            <div class="container">
                <div class="inner-banner-content">
                    <h1 class="inner-title">Create Trip</h1>
                </div>
            </div>
        </div>
        <div class="inner-shape"></div>
    </section>
    <section class="inner-banner-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3>Trip Details</h3>
                    
                </div>
            </div>
            <form action="<?php echo e(route('store_trip')); ?>" method="POST">
                <input type="hidden" name="geoId">
                <?php echo csrf_field(); ?>
                <div class="row">

                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="" class="form-label">Point of departure <span
                                    style="color: red">*</span></label>
                            <select name="departure" id="start-city-input" required onchange="enableDesField()">
                                <option value="" disabled selected>Select The City</option>
                                <option value="Islamabad">Islamabad</option>
                                <option value="" disabled>Punjab Cities</option>
                                
                                <option value="Bahawalpur">Bahawalpur</option>
                                
                                <option value="Gujranwala">Gujranwala</option>
                                
                                <option value="Lahore">Lahore</option>
                                
                                <option value="Mianwali">Mianwali</option>
                                <option value="Multan">Multan</option>
                                <option value="Murree">Murree</option>
                                
                                <option value="Sargodha">Sargodha</option>
                                
                                <option value="Sialkot">Sialkot</option>
                                
                                <option value="Wazirabad">Wazirabad</option>
                                <option value="" disabled>Sindh Cities</option>
                                
                                <option value="Hyderabad">Hyderabad</option>
                                
                                <option value="Karachi">Karachi</option>
                                
                                <option value="Mirpur Khas">Mirpur Khas</option>
                                
                                <option value="Nawabshah">Nawabshah</option>
                                
                                <option value="Rohri">Rohri</option>
                                
                                <option value="Sukkur">Sukkur</option>
                                
                                <option value="" disabled>Khyber Cities</option>
                                <option value="Abbottabad">Abbottabad</option>
                                
                                <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                                <option value="Mansehra">Mansehra</option>
                                <option value="Peshawar">Peshawar</option>
                                
                                <option value="" disabled>Balochistan Cities</option>
                                
                                <option value="Gwadar">Gwadar</option>
                                
                                <option value="Quetta">Quetta</option>
                                
                                <option value="Ziarat">Ziarat</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="" class="form-label">Budget</label>
                            <input name="budget" type="number" placeholder="Enter Budget" required
                                onchange="enableDesField(),getEstimatedAmount()">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="" class="form-label">Start Date <span style="color: red">*</span></label>
                            <input name="start_date" type="date" placeholder="Start Date" required
                                onchange="enableDesField(),getEstimatedAmount()">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="" class="form-label">End Date <span style="color: red">*</span></label>
                            <input name="end_date" type="date" placeholder="End Date" required
                                onchange="enableDesField(),getEstimatedAmount()">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="" class="form-label">Destination City</label>
                            <input id="city-input" name="destination" type="text" placeholder="Enter a city" required
                                disabled>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="" class="form-label">Estimated Amount<span
                                    style="color: red">*</span></label>
                            <input name="estimated_amount" type="text" placeholder="Estimated" required value="0"
                                disabled>
                            <span class="estimated_amount_message"></span>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <h4>Select Hotel</h4>
                            <div class="point_of_interest" id="list_hotels">
                                <!-- The hotels will be displayed here -->
                            </div>
                        </div>
                    </div>
                </div>

                <hr>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <h4>Select Point of Interest</h4>
                            <div class="point_of_interest" id="point_of_interest">

                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <h4>Select Driver (Choose Point of departure)</h4>
                            <div class="point_of_interest" id="drivers-list">
                                <!-- Drivers will be displayed here -->
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <h4>Select Food and Experices</h4>
                            <div class="point_of_interest" id="foods">

                            </div>
                        </div>
                    </div>
                </div>
                <hr>

                <div class="row">
                    <div class="col-12">
                        <h4>Weather Recommendation</h4>
                        <div id="weather-recommendation"></div>
                    </div>
                </div>

                <hr>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="button-primary">Create Trip</button>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://momentjs.com/downloads/moment.js"></script>
    <script>
        $(document).ready(function() {
            // Listen for the change event on the departure dropdown
            $('#start-city-input').change(function() {
                var selectedCity = $(this).val();

                // Make an AJAX request to fetch drivers based on the selected city
                $.ajax({
                    url: '/fetch-driver',
                    method: 'GET',
                    data: {
                        city: selectedCity
                    },
                    success: function(response) {
                        // Clear previous content
                        $('#drivers-list').empty();
                        // console.log(response);

                        // Generate radio buttons and driver information
                        $.each(response.drivers, function(index, driverData) {
                            console.log('Driver Data Object:', driverData);

                            var pricePerDay = driverData.drivers.length > 0 ? driverData
                                .drivers[0].price_per_day : 'N/A';

                            var radioButton = '<div class="card my-1">' +
                                '<div class="card-body">' +
                                '<div class="row">' +
                                '<div class="col-lg-8">' +
                                '<div class="form-check">' +
                                '<input class="form-check-input" type="radio" id="flexCheckDefault' +
                                driverData.id + '" name="driver" value="' + driverData
                                .id + '" data-price="' + driverData.drivers.price_per_day +
                                '" onchange="getEstimatedAmount()">' +
                                '<label class="form-check-label" for="flexCheckDefault' +
                                driverData.id + '">' +
                                driverData.name + ' (per day price: Rs' +  driverData.drivers.price_per_day+')'+
                                '</label>' +
                                '</div>' +
                                '<div>';


                            // Display specific properties from the main object
                            var mainPropertiesToDisplay = ['name', 'email', 'city',
                                'state', 'phone', 'age',  'price_per_day', 'vehicle_type',
                                        'availability', 'model',
                                        'manufacturer'
                            ];

                            // Add an inner loop for the nested driver details
                            if (driverData.hasOwnProperty('drivers') && Array.isArray(
                                    driverData.drivers)) {
                                $.each(driverData.drivers, function(nestedIndex,
                                    nestedDriver) {
                                    // Display specific properties from the nested driver object
                                    var nestedPropertiesToDisplay = ['address',
                                        'driver_personal_info',
                                        'price_per_day', 'vehicle_type',
                                        'availability', 'model',
                                        'manufacturer'
                                    ];

                                    $.each(nestedPropertiesToDisplay, function(
                                        nestedPropIndex, nestedPropKey
                                        ) {
                                        var nestedLowercaseKey =
                                            nestedPropKey.toLowerCase();

                                        if (nestedLowercaseKey in
                                            nestedDriver) {
                                            radioButton += '<strong>' +
                                                nestedPropKey.replace(
                                                    /_/g, ' ') +
                                                ':</strong> ' +
                                                nestedDriver[
                                                    nestedLowercaseKey
                                                    ] + '<br>';
                                        }
                                    });
                                });
                            }

                            // Display properties from the main object
                            $.each(mainPropertiesToDisplay, function(mainIndex,
                            mainKey) {
                                var mainLowercaseKey = mainKey.toLowerCase();

                                if (mainLowercaseKey in driverData) {
                                    radioButton += '<strong>' + mainKey.replace(
                                            /_/g, ' ') + ':</strong> ' +
                                        driverData[mainLowercaseKey] + '<br>';
                                }
                            });

                            radioButton += '</div>' +
                                '</div>' +
                                '<div class="col-lg-4 text-lg-right">' +
                                // Add an image source here if needed
                                '</div>' +
                                '</div>' +
                                '</div>' +
                                '</div>';

                            $('#drivers-list').append(radioButton);
                        });




                    },
                    error: function(error) {
                        console.error('Error fetching drivers:', error);
                    }
                });
            });
        });
    </script>
    <script>
        const apiKey = "<?php echo e(config('app.google_map_api_key')); ?>";
        const weatherApiKey = "382f41dbc0d4a3122776f36830f11614";
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('app.google_map_api_key')); ?>&libraries=places">
    </script>
    <script>
        $(document).ready(function() {
            initAutocomplete();
        });

        function searchPlaces(apiKey, query, type = null) {
            const baseUrl = "https://maps.googleapis.com/maps/api/place/textsearch/json";

            let url = new URL(baseUrl);
            url.searchParams.append('key', apiKey);
            url.searchParams.append('query', query);
            // url.searchParams.append('type','point_of_interest');

            if (type) {
                url.searchParams.append('type', type);
            }

            return fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'OK') {
                        return data.results;
                    } else {
                        console.error(`Error: ${data.status}`);
                        return null;
                    }
                })
                .catch(error => {
                    console.error('Error fetching data:', error);
                    return null;
                });
        }

        // show point of interest
        function showPointOfInterest(apiKey, destination) {
            const placesPromise = searchPlaces(apiKey, "Iconic places in " + destination, "point_of_interest");
            let html = 'No Resut Found';
            placesPromise.then(places => {
                if (places) {
                    html = "";
                    console.log('places', places);
                    places.forEach(place => {
                        var photos = place.photos;
                        if (photos) {
                            photos = photos[0];
                        }
                        let rating_html = '';
                        let rating = place.rating;
                        if (rating) {
                            rating = rating.toFixed(1);
                            let rating_split = rating.split('.') ?? [];
                            if (rating_split[0]) {
                                let rating_0 = rating_split[0];
                                for (let index = 0; index < rating_0; index++) {
                                    rating_html += ' <i class="fas fa-star"></i> ';
                                }
                            }
                            if (rating_split[1]) {
                                if (rating_split[1] > 0 && rating_split[1] <= 9) {
                                    rating_html += ' <i class="fas fa-star-half-alt"></i> ';
                                }
                            }
                        }
                        let hotels_url = `<?php echo e(route('hotels')); ?>`;
                        hotels_url = new URL(hotels_url);
                        hotels_url.searchParams.append('place', place.name);

                        html += `<div class="card my-1">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="flexCheckDefault${place.name}" name="point_of_interest[]" value="${place.name}">
                                        <label class="form-check-label" for="flexCheckDefault${place.name}">
                                            ${place.name}
                                        </label>
                                        </div>
                                        <div><span>${rating}</span> ${rating_html} (${place.user_ratings_total})</div>
                                        <div class="address"> <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg> ${place.formatted_address}</div>
                                    </div>
                                    <div class="col-lg-4 text-lg-right">
                                        <img src="${photos?'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference='+photos.photo_reference+'&sensor=false&key='+apiKey:''}" class="img-fluid" style="height: 140px">
                                    </div>
                                </div>
                            </div>
                        </div>`;
                    });
                }
                $(document).find('#point_of_interest').html(html);
            });
        }

        // show hotels
        function showHotels(apiKey, destination) {
            const placesPromise = searchPlaces(apiKey, "hotels in " + destination, "point_of_interest");
            let html = 'No Resut Found';
            placesPromise.then(places => {
                if (places) {
                    html = "";
                    console.log('places', places);
                    places.forEach(place => {
                        var photos = place.photos;
                        if (photos) {
                            photos = photos[0];
                        }
                        let rating_html = '';
                        let rating = place.rating;
                        if (rating) {
                            rating = rating.toFixed(1);
                            let rating_split = rating.split('.') ?? [];
                            if (rating_split[0]) {
                                let rating_0 = rating_split[0];
                                for (let index = 0; index < rating_0; index++) {
                                    rating_html += ' <i class="fas fa-star"></i> ';
                                }
                            }
                            if (rating_split[1]) {
                                if (rating_split[1] > 0 && rating_split[1] <= 9) {
                                    rating_html += ' <i class="fas fa-star-half-alt"></i> ';
                                }
                            }
                        }
                        let hotels_url = `<?php echo e(route('hotels')); ?>`;
                        hotels_url = new URL(hotels_url);
                        hotels_url.searchParams.append('place', place.name);

                        html += `<div class="card my-1">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="form-check">
                                        <input class="form-check-input" type="radio" id="flexCheckDefault${place.name}" name="hotel" value="${place.name}" data-price="4000" onchange="getEstimatedAmount()">
                                        <label class="form-check-label" for="flexCheckDefault${place.name}">
                                            ${place.name} - PKR 4,000
                                        </label>
                                        </div>
                                        <div><span>${rating}</span> ${rating_html} (${place.user_ratings_total})</div>
                                        <div class="address"> <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg> ${place.formatted_address}</div>
                                    </div>
                                    <div class="col-lg-4 text-lg-right">
                                        <img src="${photos?'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference='+photos.photo_reference+'&sensor=false&key='+apiKey:''}" class="img-fluid" style="height: 140px">
                                    </div>
                                </div>
                            </div>
                        </div>`;
                    });
                }
                $(document).find('#list_hotels').html(html);
            });
        }

        // show foods
        function showFoods(apiKey, destination) {
            const placesPromise = searchPlaces(apiKey, "foods in " + destination, "foods");
            let html = 'No Resut Found';
            placesPromise.then(places => {
                if (places) {
                    html = "";
                    console.log('places', places);
                    places.forEach(place => {
                        var photos = place.photos;
                        if (photos) {
                            photos = photos[0];
                        }
                        let rating_html = '';
                        let rating = place.rating;
                        if (rating) {
                            rating = rating.toFixed(1);
                            let rating_split = rating.split('.') ?? [];
                            if (rating_split[0]) {
                                let rating_0 = rating_split[0];
                                for (let index = 0; index < rating_0; index++) {
                                    rating_html += ' <i class="fas fa-star"></i> ';
                                }
                            }
                            if (rating_split[1]) {
                                if (rating_split[1] > 0 && rating_split[1] <= 9) {
                                    rating_html += ' <i class="fas fa-star-half-alt"></i> ';
                                }
                            }
                        }
                        let hotels_url = `<?php echo e(route('hotels')); ?>`;
                        hotels_url = new URL(hotels_url);
                        hotels_url.searchParams.append('place', place.name);

                        html += `<div class="card my-1">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="${place.name}" id="flexCheckDefault${place.name}" name="foods[]">
                                        <label class="form-check-label" for="flexCheckDefault${place.name}">
                                            ${place.name}
                                        </label>
                                        </div>
                                        <div><span>${rating}</span> ${rating_html} (${place.user_ratings_total})</div>
                                        <div class="address"> <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg> ${place.formatted_address}</div>
                                    </div>
                                    <div class="col-lg-4 text-lg-right">
                                        <img src="${photos?'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference='+photos.photo_reference+'&sensor=false&key='+apiKey:''}" class="img-fluid" style="height: 140px">
                                    </div>
                                </div>
                            </div>
                        </div>`;
                    });
                }
                $(document).find('#foods').html(html);
            });
        }

        function getWeatherRecommendation(temperature) {
            if (temperature > 25) {
                return `It's a warm day (${temperature}°C)! Pack light and stay hydrated.`;
            } else if (temperature > 10) {
                return `The weather is moderate (${temperature}°C). Bring a jacket just in case.`;
            } else {
                return `It's a cold day (${temperature}°C). Make sure to bundle up.`;
            }
        }


        function getWeatherData(city) {
            const weatherUrl =
                `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${weatherApiKey}&units=metric`;

            return fetch(weatherUrl)
                .then(response => response.json())
                .then(data => {
                    if (data.main && data.main.temp) {
                        return data.main.temp;
                    } else {
                        console.error('Error fetching weather data:', data);
                        return null;
                    }
                })
                .catch(error => {
                    console.error('Error fetching weather data:', error);
                    return null;
                });
        }

        // Function to update weather recommendation on the page
        function updateWeatherRecommendation(city) {
            getWeatherData(city)
                .then(temperature => {
                    if (temperature !== null) {
                        const recommendation = getWeatherRecommendation(temperature);
                        const weatherRecommendationDiv = $('#weather-recommendation');
                        weatherRecommendationDiv.text(recommendation);
                    }
                });
        }


        // Example usage
        const userQuery = $(document).find('input[name=place]').val();

        function initAutocomplete() {
            var input = document.getElementById('city-input');
            var autocomplete = new google.maps.places.Autocomplete(input, {
                types: ['(cities)'],
                componentRestrictions: {
                    country: 'PK'
                } // 'PK' is the ISO 3166-1 alpha-2 country code for Pakistan
            });

            autocomplete.addListener('place_changed', function() {
                var place = autocomplete.getPlace();
                localStorage.setItem('destinaition', place)
                showPointOfInterest(apiKey, place.name);
                showHotels(apiKey, place.name);
                showFoods(apiKey, place.name);

                updateWeatherRecommendation(place.name);

                // fetch the geolocation id
                // var geoId = null;
                // var myHeaders = new Headers();
                // myHeaders.append("X-RapidAPI-Key", "fab8861b1fmshad0a73ec647ea64p1d7b9fjsne90aeb42946c");
                // myHeaders.append("X-RapidAPI-Host", "tripadvisor16.p.rapidapi.com");

                // var requestOptions = {
                // method: 'GET',
                // headers: myHeaders,
                // redirect: 'follow'
                // };
                // let fetchLocationUrl = encodeURI("https://tripadvisor16.p.rapidapi.com/api/v1/hotels/searchLocation?query="+place.name);
                // console.log('fetchLocationUrl',fetchLocationUrl);
                // fetch(fetchLocationUrl, requestOptions)
                // .then(response => response.text())
                // .then(result => {
                //     result = JSON.parse(result);
                //     console.log('result',result);
                //     console.log('status',result.status);
                //     console.log('data',result.data[0].geoId);
                //     if(result.status){
                //         let data = result.data[0]??null;
                //         if(data&&data.geoId){
                //             $('input[name="geoId"]').val(data.geoId);
                //             geoId = data.geoId;
                //             showHotels2(geoId);
                //         }
                //     }
                // })
                // .catch(error => console.log('error', error));


            });
        }

        function enableDesField() {
            if ($.trim($('select[name="departure"]').val()) != '' && $.trim($('input[name="budget"]').val()) != '' &&
                $.trim($('input[name="start_date"]').val()) != '' &&
                $.trim($('input[name="end_date"]').val()) != '') {
                $('input[name="destination"]').attr('disabled', false)
            } else {
                $('input[name="destination"]').attr('disabled', true)
            }
        }

        function showHotels2(geoId) {
            console.log('showHotels2');
            var myHeaders = new Headers();
            myHeaders.append("X-RapidAPI-Key", "fab8861b1fmshad0a73ec647ea64p1d7b9fjsne90aeb42946c");
            myHeaders.append("X-RapidAPI-Host", "tripadvisor16.p.rapidapi.com");

            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };

            fetch("https://tripadvisor16.p.rapidapi.com/api/v1/hotels/searchHotels?geoId=" + geoId +
                    "&checkIn=2024-01-18&checkOut=2024-01-31&pageNumber=1&currencyCode=PKR", requestOptions)
                .then(response => response.text())
                .then(result => {

                    result = JSON.parse(result);
                    var data = result.data.data;
                    console.log('data', data)
                    let html = '';
                    data.forEach(place => {
                        let rating_html = '';
                        let rating = place.bubbleRating.rating;
                        if (rating) {
                            rating = rating.toFixed(1);
                            let rating_split = rating.split('.') ?? [];
                            if (rating_split[0]) {
                                let rating_0 = rating_split[0];
                                for (let index = 0; index < rating_0; index++) {
                                    rating_html += ' <i class="fas fa-star"></i> ';
                                }
                            }
                            if (rating_split[1]) {
                                if (rating_split[1] > 0 && rating_split[1] <= 9) {
                                    rating_html += ' <i class="fas fa-star-half-alt"></i> ';
                                }
                            }
                        }
                        let hotelPhoto = place.cardPhotos[0] ?? null;
                        let updatedUrlUpdated = undefined;
                        if (hotelPhoto) {
                            hotelPhoto = hotelPhoto.sizes.urlTemplate;
                            // Replace placeholders with the values 300
                            let updatedUrlUpdated = hotelPhoto.replace("{width}", "300").replace("{height}",
                                "300");
                            console.log('updatedUrlUpdated', updatedUrlUpdated);
                            html += `<div class="card my-1">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="form-check">
                                        <input class="form-check-input" type="radio" id="flexCheckDefault${place.title}" name="hotel" value="${place.title}" data-price="4000">
                                        <label class="form-check-label" for="flexCheckDefault${place.title}">
                                            ${place.title} - PKR 4,000
                                        </label>
                                        </div>
                                        <div><span>${place.bubbleRating.rating}</span> ${rating_html} (${place.bubbleRating.count})</div>
                                        <div class="address"> <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg>${place.primaryInfo} - ${place.primaryInfo} - ${place.priceForDisplay}</div>
                                    </div>
                                    <div class="col-lg-4 text-lg-right">
                                        <img src="${updatedUrlUpdated}" class="img-fluid" style="height: 140px">
                                    </div>
                                </div>
                            </div>
                        </div>`;
                        }
                    });
                    $(document).find('#list_hotels').html(html);
                })
                .catch(error => console.log('error', error));
        }

        function getEstimatedAmount() {
            let estimatedAmount = 0;
            let selectedHotel = $('input[name="hotel"]:checked');
            let selectedDriver = $('input[name="driver"]:checked');
            let perDayPrice = selectedHotel.attr('data-price');
            let driverDayPrice = selectedDriver.attr('data-price');
            var startDate = moment($('input[name="start_date"]').val());
            var endDate = moment($('input[name="end_date"]').val());
            const numberOfDays = endDate.diff(startDate, 'days');
            let hotelCost = 0;
            let driverCost = 0;
            if (numberOfDays > 0 && perDayPrice > 0) {
                hotelCost = numberOfDays * perDayPrice;
            }
            if (numberOfDays > 0 && driverDayPrice > 0) {
                driverCost = numberOfDays * driverDayPrice;
            }
            estimatedAmount = hotelCost + driverCost;
            estimatedAmount = parseFloat(estimatedAmount);
            $('input[name="estimated_amount"]').val(estimatedAmount)
            setTimeout(() => {
                let budgetAount = parseFloat($('input[name="budget"]').val());
                console.log('budgetAount', budgetAount);
                if (estimatedAmount > budgetAount || isNaN(budgetAount) || budgetAount == 0) {
                    $('.estimated_amount_message').addClass('text-danger').removeClass('text-success').text(
                        'Budget is not enough for this trip');
                    $('button[type="submit"]').attr('disabled', true);
                } else {
                    $('.estimated_amount_message').addClass('text-success').removeClass('text-danger').text(
                        'All good');
                    $('button[type="submit"]').attr('disabled', false);
                }
            }, 100);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/mainpages/create_trip.blade.php ENDPATH**/ ?>