<?php $__env->startSection('title', 'Complain Trip'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <style>
            .point_of_interest {
                max-height: 500px;
                overflow-y: auto;
            }

            .h-label {
                font-weight: 700;
                font-size: 28px;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <section class="inner-banner-wrap">
        <div class="inner-baner-container" style="background-image: url(<?php echo e(asset('assets/images/inner-banner.jpg')); ?>);">
            <div class="container">
                <div class="inner-banner-content">
                    <h1 class="inner-title">Complain Againts Driver</h1>
                </div>
            </div>
        </div>
        <div class="inner-shape"></div>
    </section>
    <section class="inner-banner-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3>Complain Againts Driver</h3>
                </div>
            </div>
            <form action="<?php echo e(route('complain.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($trip->id); ?>" name="trip_id">
                <div class="row">
                 
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="" class="form-label">Complaint</label>
                        <textarea name="message" id="" cols="30" rows="10"></textarea>
                        </div>
                    </div>
                 
                </div>
                <hr>
           
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="button-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <script>
        <?php if(session('error')): ?>
            swal({
                title: "Error",
                text: "<?php echo e(session('error')); ?>",
                icon: "error",
                button: "OK",
            });
        <?php endif; ?>
        <?php if(session('success')): ?>
            swal({
                title: "Success",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\umer\new\resources\views/tourist/complain.blade.php ENDPATH**/ ?>