<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HotelVendorController extends Controller
{
    public function dashboard()
    {
        dd("Vendor");
    }
}
